# MRI Planning Simulator — Phase 1 update

A local, educational MRI planning simulator. It does **not** connect to an MRI scanner and is not for diagnosis or clinical planning.

## Current capabilities
- Imports DICOM image files from one MRI series.
- Builds synchronized axial, coronal and sagittal voxel-axis views.
- Moves the crosshair through the volume.
- Shows voxel dimensions and physical spacing in millimetres.
- Orders slices by their position projected onto the DICOM slice normal (rather than sorting only by patient Z).
- Applies `RescaleSlope` and `RescaleIntercept` per slice.
- Validates Series UID, matrix dimensions, pixel spacing and image orientation before assembling the volume.
- Includes a basic health endpoint at `/api/health`.

## Requirements
- Python 3.10+
- A modern browser

## Run
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Create and activate a virtual environment:
   - `python -m venv .venv`
   - Windows: `.venv\\Scripts\\activate`
   - macOS/Linux: `source .venv/bin/activate`
4. Install requirements: `pip install -r backend/requirements.txt`
5. Start the server: `uvicorn backend.app:app --reload`
6. Open `http://127.0.0.1:8000`.

## DICOM compatibility and limitations
- Select one image Series at a time. Do not mix studies or series.
- Optional `pylibjpeg` decoder packages are included for common JPEG, JPEG-LS and JPEG 2000 transfer syntaxes. Actual support depends on the codec and platform.
- The current display is still limited to near-axial, consistently oriented acquisitions. Oblique patient-space MPR, interpolation, gantry/table geometry, irregular slice resampling and true angled prescription are **not implemented yet**.
- Coronal and sagittal views are voxel-axis reformats; this version must not be used to prescribe clinical scans.
- De-identify training files and use only data you are authorized to use.

## Next milestones
1. Add automated DICOM geometry tests and robust handling of enhanced multi-frame objects.
2. Implement patient-coordinate resampling and true oblique MPR with interpolation.
3. Make FOV, slice thickness, gap and slice count drive a real prescription preview.
4. Add protocol library, training tasks, scoring and progress tracking.
