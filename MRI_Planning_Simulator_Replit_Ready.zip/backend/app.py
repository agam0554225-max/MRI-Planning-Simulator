"""Local educational DICOM volume viewer. Not for clinical use."""
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, Response
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from PIL import Image
import pydicom
import numpy as np
import io
import uuid
from pydicom.errors import InvalidDicomError

app = FastAPI(title="MRI Planning Simulator", version="0.2.0")
ROOT = Path(__file__).resolve().parents[1]
app.mount("/static", StaticFiles(directory=ROOT / "frontend"), name="static")
VOLUMES = {}


def _first_number(value, fallback):
    """Read a scalar or first value from a DICOM multi-value field."""
    if value is None:
        return float(fallback)
    try:
        return float(value[0] if isinstance(value, (list, tuple, pydicom.multival.MultiValue)) else value)
    except (TypeError, ValueError, IndexError):
        return float(fallback)


def _error(message):
    raise HTTPException(status_code=400, detail=message)


@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "frontend" / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {"status": "ok", "version": app.version, "loaded_volumes": len(VOLUMES)}


@app.post("/api/volume")
async def upload_volume(files: list[UploadFile] = File(...)):
    slices = []
    skipped = 0
    for f in files:
        raw = await f.read()
        try:
            ds = pydicom.dcmread(io.BytesIO(raw), force=False)
            if not hasattr(ds, "PixelData") or not all(hasattr(ds, k) for k in
                    ("ImagePositionPatient", "ImageOrientationPatient", "PixelSpacing")):
                skipped += 1
                continue
            arr = ds.pixel_array.astype(np.float32)
            if arr.ndim != 2:
                skipped += 1
                continue
            ipp = np.asarray(ds.ImagePositionPatient, dtype=np.float64)
            iop = np.asarray(ds.ImageOrientationPatient, dtype=np.float64)
            pixel_spacing = np.asarray(ds.PixelSpacing, dtype=np.float64)
            if ipp.shape != (3,) or iop.shape != (6,) or pixel_spacing.shape != (2,):
                skipped += 1
                continue
            if not np.all(np.isfinite(ipp)) or not np.all(np.isfinite(iop)) or not np.all(np.isfinite(pixel_spacing)):
                skipped += 1
                continue
            if np.any(pixel_spacing <= 0):
                skipped += 1
                continue
            slices.append({"ipp": ipp, "iop": iop, "pixel_spacing": pixel_spacing,
                           "ds": ds, "pixels": arr})
        except (InvalidDicomError, AttributeError, NotImplementedError, ValueError,
                RuntimeError, OSError):
            # RuntimeError commonly indicates a missing decoder for compressed pixel data.
            skipped += 1

    if len(slices) < 3:
        _error("لم يتم العثور على 3 شرائح DICOM صالحة على الأقل. تأكد من اختيار صور من Series واحدة وأن ترميز الصور مدعوم.")

    # One series only: mixing series can create a geometrically invalid volume.
    series_uids = {str(getattr(s["ds"], "SeriesInstanceUID", "")) for s in slices}
    if len(series_uids) != 1:
        _error("الملفات المختارة تحتوي على أكثر من Series. اختَر سلسلة واحدة فقط.")

    # Validate common matrix and in-plane geometry.
    ref = slices[0]
    rows_cols = ref["pixels"].shape
    ref_iop = ref["iop"]
    ref_spacing = ref["pixel_spacing"]
    if any(s["pixels"].shape != rows_cols for s in slices):
        _error("أبعاد الصور غير متطابقة. تأكد من اختيار Series واحدة.")
    if any(np.max(np.abs(s["iop"] - ref_iop)) > 1e-4 for s in slices):
        _error("اتجاه الصور غير متطابق. لا يمكن تكوين Volume موثوق من هذه الملفات.")
    if any(np.max(np.abs(s["pixel_spacing"] - ref_spacing)) > 1e-4 for s in slices):
        _error("Pixel Spacing غير متطابق بين الشرائح.")

    # DICOM ImageOrientationPatient: first triplet is the increasing-column
    # direction, second triplet is the increasing-row direction.
    col_dir, row_dir = ref_iop[:3], ref_iop[3:]
    if abs(np.linalg.norm(col_dir) - 1) > 1e-3 or abs(np.linalg.norm(row_dir) - 1) > 1e-3:
        _error("قيم Image Orientation غير صالحة.")
    if abs(float(np.dot(col_dir, row_dir))) > 1e-3:
        _error("اتجاهات البكسل في DICOM ليست متعامدة بشكل صحيح.")
    normal = np.cross(col_dir, row_dir)
    normal /= np.linalg.norm(normal)

    # Correct ordering is by projection onto the slice normal, not patient Z.
    for s in slices:
        s["position"] = float(np.dot(s["ipp"], normal))
    slices.sort(key=lambda s: s["position"])
    positions = np.asarray([s["position"] for s in slices], dtype=np.float64)
    diffs = np.diff(positions)
    if np.any(diffs <= 1e-4):
        _error("توجد شرائح مكررة أو مواضع غير مرتبة هندسيًا داخل السلسلة.")
    slice_spacing = float(np.median(diffs))
    if np.max(np.abs(diffs - slice_spacing)) > max(0.1, slice_spacing * 0.05):
        _error("المسافات بين الشرائح غير منتظمة. هذه النسخة لا تعيد أخذ عينات للـ irregular spacing بعد.")

    # This viewer currently labels voxel-axis views as axial/coronal/sagittal;
    # reject substantially oblique acquisitions until patient-space MPR lands.
    if abs(float(normal[2])) < 0.985:
        _error("السلسلة مائلة/Oblique بدرجة لا تدعمها هذه المرحلة بعد. دعم Patient-space Oblique MPR قادم في المرحلة التالية.")

    # Apply modality rescale independently to every slice (not just slice 1).
    planes = []
    for s in slices:
        ds = s["ds"]
        slope = float(getattr(ds, "RescaleSlope", 1) or 1)
        intercept = float(getattr(ds, "RescaleIntercept", 0) or 0)
        planes.append(s["pixels"] * slope + intercept)
    volume = np.stack(planes, axis=0)

    ds = slices[0]["ds"]
    default_wc = float(np.percentile(volume, 50))
    default_ww = float(np.percentile(volume, 99) - np.percentile(volume, 1))
    wc = _first_number(getattr(ds, "WindowCenter", None), default_wc)
    ww = max(_first_number(getattr(ds, "WindowWidth", None), default_ww), 1.0)
    key = str(uuid.uuid4())
    spacing = [float(ref_spacing[0]), float(ref_spacing[1]), slice_spacing]
    VOLUMES[key] = {
        "v": volume, "wc": wc, "ww": ww, "spacing": spacing,
        "patient": str(getattr(ds, "PatientName", "Training case")),
        "series": str(getattr(ds, "SeriesDescription", "MRI series")),
        "orientation": normal.tolist(), "skipped": skipped,
    }
    return {"id": key, "shape": list(volume.shape), "spacing": spacing,
            "patient": VOLUMES[key]["patient"], "series": VOLUMES[key]["series"],
            "slices": len(slices), "skipped": skipped,
            "geometry": "slice-normal projection", "version": app.version}


@app.get("/api/slice/{volume_id}/{plane}/{index}")
def get_slice(volume_id: str, plane: str, index: int):
    if volume_id not in VOLUMES:
        raise HTTPException(404, "Volume not found")
    item = VOLUMES[volume_id]
    v = item["v"]
    if plane == "axial":
        a = v[np.clip(index, 0, v.shape[0] - 1), :, :]
    elif plane == "coronal":
        a = v[:, np.clip(index, 0, v.shape[1] - 1), :]
    elif plane == "sagittal":
        a = v[:, :, np.clip(index, 0, v.shape[2] - 1)]
    else:
        raise HTTPException(400, "Unknown plane")
    lo = item["wc"] - item["ww"] / 2
    hi = item["wc"] + item["ww"] / 2
    a = np.clip((a - lo) / max(hi - lo, 1e-6), 0, 1)
    im = Image.fromarray((a * 255).astype(np.uint8)).convert("L")
    im = im.transpose(Image.Transpose.FLIP_TOP_BOTTOM)
    buf = io.BytesIO()
    im.save(buf, format="PNG")
    return Response(buf.getvalue(), media_type="image/png")


@app.get("/api/info/{volume_id}")
def info(volume_id: str):
    if volume_id not in VOLUMES:
        raise HTTPException(404, "Volume not found")
    x = VOLUMES[volume_id]
    return {"shape": list(x["v"].shape), "spacing": x["spacing"],
            "patient": x["patient"], "series": x["series"],
            "orientation_normal": x["orientation"], "skipped_files": x["skipped"]}
