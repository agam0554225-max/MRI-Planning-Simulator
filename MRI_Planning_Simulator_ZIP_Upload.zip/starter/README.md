# MRI Planning Simulator — starter

A local, educational MRI planning simulator. It does **not** connect to an MRI scanner and is not for diagnosis or clinical planning.

## What this first version does
- Imports a folder/selection of real DICOM image files from one MRI series.
- Builds synchronized axial, coronal and sagittal views from the uploaded volume.
- Lets the learner move the crosshair through the volume.
- Provides a rotatable planning overlay and editable training parameters (FOV, slice thickness, gap, slice count).
- Keeps the data local to the computer running the app.

## Requirements
- Python 3.10+
- A browser

## Run
1. Extract the ZIP.
2. Open a terminal in the extracted folder.
3. Install backend requirements:
   `python -m venv .venv`
   - Windows: `.venv\\Scripts\\activate`
   - macOS/Linux: `source .venv/bin/activate`
   `pip install -r backend/requirements.txt`
4. Start the server:
   `uvicorn backend.app:app --reload`
5. Open `http://127.0.0.1:8000`

## DICOM notes
- Select a single image series at a time (all slices from the same series).
- This starter supports conventional, consistently oriented, uncompressed DICOM pixel data. Compressed transfer syntaxes may require installing a decoder such as `pylibjpeg`/`gdcm`.
- The first version assumes a near-axial acquisition for ordering and orthogonal reformatting. It checks orientation and rejects obviously inconsistent series rather than silently producing misleading views.
- De-identify training files and use only data you are authorized to use.

## Next engineering milestones
1. Robust DICOM geometry/orientation handling and compressed transfer syntaxes.
2. True oblique MPR with interpolation and slab thickness/spacing.
3. Sequence/protocol library for Brain, Spine, MSK, Abdomen, Pelvis, Cardiac, Breast and MRA/MRV.
4. Training tasks, reference planning, scoring and progress tracking.
5. User accounts and optional institutional deployment.


## ZIP upload update
The interface accepts a ZIP archive containing `.dcm`/`.dicom` files or multiple individual DICOM files. The backend extracts instances in memory and selects the most populated SeriesInstanceUID. Current limitation: axial-oriented series only; educational use only, not diagnosis or clinical decisions.
